export const metadata = { title: "Maarlab — Change Visualizer", description: "Backoffice visualizer" };
import "./globals.css";
export default function RootLayout({ children }) { return (<html lang="es"><body>{children}</body></html>); }
