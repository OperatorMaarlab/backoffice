"use client";
import ChangeVisualizer from "@/components/ChangeVisualizer";
export default function Page(){return <ChangeVisualizer/>}
