# Maarlab Backoffice — Change/Quotation Visualizer (ES/EN)

A tiny Next.js app that generates PNG cards for flight changes/quotations.

## Quick start (copy/paste)
```bash
# 1) clone your repo locally (replace with your GitHub URL)
git clone https://github.com/OperatorMaarlab/backoffice.git
cd backoffice

# 2) copy these starter files into the repo directory
# (unzip the file you downloaded and move its content here)

# 3) install
npm install

# 4) run
npm run dev
# open http://localhost:3000
```

## Assets
- Airline logos → `public/assets/airlines/IB.png`, `UX.png`, `VY.png`, ... (uppercase IATA)
- Hotel logos → `public/assets/hotels/h10_conquistador.png`, ... (lowercase slug)
- Maarlab logo → `public/assets/maarlab/logo.png` (PNG, transparent)

## Build / Deploy
```bash
npm run build
npm start   # local preview
# push to GitHub and connect to Vercel for production
```
