// Usage:
// 1) Put all your airline logos (any names) into a temp folder, ideally as PNGs.
// 2) Edit the list below to map filename keywords -> IATA codes if needed.
// 3) Run: node tools/rename-airline-logos.mjs /path/to/temp-logos ./public/assets/airlines
import fs from 'fs';
import path from 'path';

const keywordToIata = {
  // extend this map as needed (left side appears in filename; right side is IATA)
  'iberia': 'IB',
  'air_europa': 'UX',
  'vueling': 'VY',
  'ryanair': 'FR',
  'jet2': 'LS',
  'easyjet': 'U2',
  'latam': 'LA',
  'lufthansa': 'LH',
  'american': 'AA',
  'united': 'UA',
  'delta': 'DL',
  'binter': 'NT',
};

function slug(s) { return String(s).toLowerCase().replace(/[^a-z0-9]+/g,'_'); }

const src = process.argv[2];
const dst = process.argv[3] || './public/assets/airlines';
if (!src) { console.error('Please provide a source folder'); process.exit(1); }
if (!fs.existsSync(dst)) fs.mkdirSync(dst, { recursive: true });

const files = fs.readdirSync(src).filter(f => /\.(png|svg|jpg|jpeg)$/i.test(f));
for (const f of files) {
  const base = path.basename(f).toLowerCase();
  // Try to detect IATA by filename keyword
  let iata = null;
  for (const [kw, code] of Object.entries(keywordToIata)) {
    if (base.includes(kw)) { iata = code; break; }
  }
  // If filename already starts with an IATA code, keep it
  const m = base.match(/^([a-z0-9]{2,3})/i);
  if (!iata && m) iata = m[1].toUpperCase();

  if (!iata) { console.log('Skip (no IATA detected):', f); continue; }

  let out = path.join(dst, `${iata}.png`);
  fs.copyFileSync(path.join(src, f), out);
  console.log('Copied ->', out);
}
